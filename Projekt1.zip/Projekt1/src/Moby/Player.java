package Entities;

import Abstrakcje.Entity;

public class Player extends Entity {
    private String name;

    public Player(String name, int health) {
        super(health);
        this.name = name;
    }

    @Override
    public void hit(int damage) {
        setHealth(getHealth() - damage);
        if (getHealth() <= 0) {
            kill();
        }
    }

    @Override
    public void kill() {
        setHealth(0);
        System.out.println(name + " has been killed.");
    }

    @Override
    public String getStatus() {
        return name + " has " + getHealth() + " health and is " + (isOnFire() ? "on fire" : "not on fire") + ".";
    }

    public boolean isDead() {
        return getHealth() <= 0;
    }
}
