package Moby;

import Abstrakcje.Entity;

public class Creeper extends Entity {

    public Creeper(int health) {
        super(health);
    }

    @Override
    public void hit(int damage) {
        setHealth(getHealth() - damage);
        if (getHealth() <= 0) {
            kill();
        }
    }

    @Override
    public void kill() {
        setHealth(0);
        System.out.println("Creeper has been killed.");
    }

    @Override
    public String getStatus() {
        return "Creeper has " + getHealth() + " health and is " + (isOnFire() ? "on fire" : "not on fire") + ".";
    }
}
