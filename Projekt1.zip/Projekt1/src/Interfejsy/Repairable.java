package Interfejsy;

public interface Repairable {
    void repair();

}
