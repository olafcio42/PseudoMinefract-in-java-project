package Interfejsy;

public interface Upgradable {

    void upgrade();

}
