package Interfejsy;

public interface Stackable {
    int count();
    void addToStack(Stackable item);
    void removeFromStack();
}
