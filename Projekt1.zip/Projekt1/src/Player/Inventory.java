package Player;

import Abstrakcje.Block;
import Abstrakcje.Item;
import Interfejsy.Stackable;

public class Inventory {
    private Item[] items;
    private int[] itemCounts;

    public Inventory() {
        items = new Item[36]; // Initialize with 36 slots
        itemCounts = new int[36]; // Initialize counts for stackable items
    }

    public void addItem(Item item, int slot) {
        if (slot < 1 || slot > 36) {
            System.out.println("Invalid slot number. Choose a slot between 1 and 36.");
            return;
        }
        int index = slot - 1;
        if (items[index] == null) {
            items[index] = item;
            itemCounts[index] = 1;
            System.out.println("Item added to slot " + slot);
        } else if (items[index].getClass() == item.getClass() && item instanceof Stackable) {
            if (itemCounts[index] < 64) {
                itemCounts[index]++;
                System.out.println("Item stack increased in slot " + slot);
            } else {
                System.out.println("Slot " + slot + " is full.");
            }
        } else {
            System.out.println("Slot " + slot + " is already occupied by a different item.");
        }
    }

    public boolean containsItem(Class<? extends Item> itemClass) {
        for (Item item : items) {
            if (item != null && item.getClass() == itemClass) {
                return true;
            }
        }
        return false;
    }

    public void removeItem(Class<? extends Item> itemClass) {
        for (int i = 0; i < items.length; i++) {
            if (items[i] != null && items[i].getClass() == itemClass) {
                items[i] = null;
                itemCounts[i] = 0;
                System.out.println(itemClass.getSimpleName() + " removed from inventory.");
                break;
            }
        }
    }

    public int getItemCount() {
        int count = 0;
        for (int i = 0; i < items.length; i++) {
            if (items[i] != null) {
                count += itemCounts[i];
            }
        }
        return count;
    }

    public void displayItems() {
        for (int i = 0; i < items.length; i++) {
            if (items[i] != null) {
                System.out.println("Slot " + (i + 1) + ": " + items[i].getClass().getSimpleName() + " x" + itemCounts[i]);
            } else {
                System.out.println("Slot " + (i + 1) + ": empty");
            }
        }
    }

    public int getEmptySlot() {
        for (int i = 0; i < 36; i++) {
            if (items[i] == null) {
                return i + 1;
            }
        }
        return -1; // No empty slots
    }

    public boolean canAddItem(Item item, int slot) {
        if (slot < 1 || slot > 36) {
            return false;
        }
        int index = slot - 1;
        if (items[index] == null || (items[index].getClass() == item.getClass() && item instanceof Stackable && itemCounts[index] < 64)) {
            return true;
        }
        return false;
    }
}
