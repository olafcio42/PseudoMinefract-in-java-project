package Blocks;

import Abstrakcje.Block;
import Abstrakcje.Tool;
import Interfejsy.Stackable;
import Itemy.Shovel;

public class Dirt extends Block implements Stackable {
    private int stackSize;

    public Dirt() {
        this.durability = 20; // Example durability for Dirt block
        this.stackSize = 1;
    }

    public void place(int x, int y) {
        System.out.println("Placing dirt at " + x + ", " + y);
    }

    public boolean canBeMinedWith(Tool tool) {
        return tool instanceof Shovel;
    }

    // Stackable methods
    public int count() {
        return stackSize;
    }

    public void addToStack(Stackable item) {
        if (stackSize + 1 <= 64) {
            stackSize++;
        }
    }

    public void removeFromStack() {
        if (stackSize > 0) {
            stackSize--;
        }
    }
}
