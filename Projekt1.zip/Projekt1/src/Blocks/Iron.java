package Blocks;

import Abstrakcje.Block;
import Abstrakcje.Tool;
import Interfejsy.Stackable;
import Itemy.Pickaxe;
import WorldMap.Map;

public class Iron extends Block implements Stackable {
    private int stackSize;

    public Iron() {
        this.durability = 50; // Przykładowa wytrzymałość dla bloku Iron
        this.stackSize = 1;
    }


    public void place(int x, int y) {
        System.out.println("Placing iron at " + x + ", " + y);
    }


    public void mine(Map worldMap, int x, int y, Tool tool) {
        if (canBeMinedWith(tool)) {
            tool.use(this, worldMap, x, y);
            if (isDestroyed()) {
                worldMap.removeBlock(x, y);
                System.out.println("Iron block mined successfully.");
            } else {
                System.out.println("Iron block is damaged but not destroyed.");
            }
        } else {
            System.out.println("Wrong tool used for mining iron.");
        }
    }


    public void collect() {
        System.out.println("Iron collected");
    }

    @Override
    public int count() {
        return stackSize;
    }

    @Override
    public void addToStack(Stackable item) {
        if (stackSize + 1 <= 64) {
            stackSize++;
        }
    }

    @Override
    public void removeFromStack() {
        if (stackSize > 0) {
            stackSize--;
        }
    }

    public boolean canBeMinedWith(Tool tool) {
        return tool instanceof Pickaxe;
    }
}
