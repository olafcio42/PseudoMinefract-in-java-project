package Blocks;

import Abstrakcje.Block;
import Abstrakcje.Tool;
import Interfejsy.Stackable;
import Itemy.Shovel;
import WorldMap.Map;

public class Gravel extends Block implements Stackable {
    private int stackSize;

    public Gravel() {
        this.durability = 30; // Przykładowa wytrzymałość dla bloku Gravel
        this.stackSize = 1;
    }

    public void place(int x, int y) {
        System.out.println("Placing gravel at " + x + ", " + y);
    }

    public void mine(Map worldMap, int x, int y, Tool tool) {
        if (canBeMinedWith(tool)) {
            tool.use(this, worldMap, x, y);
            if (isDestroyed()) {
                worldMap.removeBlock(x, y);
                System.out.println("Gravel block mined successfully.");
            } else {
                System.out.println("Gravel block is damaged but not destroyed.");
            }
        } else {
            System.out.println("Wrong tool used for mining gravel.");
        }
    }

    public void collect() {
        System.out.println("Gravel collected");
    }

    public int count() {
        return stackSize;
    }

    public void addToStack(Stackable item) {
        if (stackSize + 1 <= 64) {
            stackSize++;
        }
    }

    public void removeFromStack() {
        if (stackSize > 0) {
            stackSize--;
        }
    }

    public boolean canBeMinedWith(Tool tool) {
        return tool instanceof Shovel;
    }
}
