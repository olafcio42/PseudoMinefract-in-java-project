package Blocks;

import Abstrakcje.Block;
import Abstrakcje.Tool;
import Interfejsy.Stackable;
import Itemy.Axe;
import WorldMap.Map;

public class Wood extends Block implements Stackable {
    private int stackSize;

    public Wood() {
        this.durability = 40; // Przykładowa wytrzymałość dla bloku Wood
        this.stackSize = 1;
    }

    public void place(int x, int y) {
        System.out.println("Placing wood at " + x + ", " + y);
    }

    public void mine(Map worldMap, int x, int y, Tool tool) {
        if (canBeMinedWith(tool)) {
            tool.use(this, worldMap, x, y);
            if (isDestroyed()) {
                worldMap.removeBlock(x, y);
                System.out.println("Wood block mined successfully.");
            } else {
                System.out.println("Wood block is damaged but not destroyed.");
            }
        } else {
            System.out.println("Wrong tool used for mining wood.");
        }
    }

    public void collect() {
        System.out.println("Wood collected");
    }

    public int count() {
        return stackSize;
    }

    public void addToStack(Stackable item) {
        if (stackSize + 1 <= 64) {
            stackSize++;
        }
    }

    public void removeFromStack() {
        if (stackSize > 0) {
            stackSize--;
        }
    }

    public boolean canBeMinedWith(Tool tool) {
        return tool instanceof Axe;
    }
}
