package Abstrakcje;

public interface Item {
    // Common methods for all items can be defined here.
}
