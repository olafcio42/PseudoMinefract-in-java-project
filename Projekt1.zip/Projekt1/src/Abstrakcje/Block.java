package Abstrakcje;

public abstract class Block implements Item {
   protected int durability;

   public void reduceDurability(int amount) {
      durability -= amount;
      if (durability < 0) {
         durability = 0;
      }
   }

   public boolean isDestroyed() {
      return durability <= 0;
   }

   public int getDurability() {
      return durability;
   }

   public abstract boolean canBeMinedWith(Tool tool);
}
