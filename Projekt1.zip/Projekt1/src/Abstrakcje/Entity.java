package Abstrakcje;

public abstract class Entity {
    private int health;
    private boolean onFire;

    public Entity(int health) {
        this.health = health;
        this.onFire = false;
    }

    public abstract void hit(int damage);
    public abstract void kill();
    public abstract String getStatus();

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public boolean isOnFire() {
        return onFire;
    }

    public void setOnFire(boolean onFire) {
        this.onFire = onFire;
    }
}
