package Abstrakcje;

import WorldMap.Map;

public abstract class Tool implements Item {
    private int durability;
    private final int miningSpeed;

    public Tool(int durability, int miningSpeed) {
        this.durability = durability;
        this.miningSpeed = miningSpeed;
    }

    public boolean isBroken() {
        return durability <= 0;
    }

    public void decreaseDurability() {
        if (durability > 0) {
            durability--;
        }
    }

    public int getDurability() {
        return durability;
    }

    public int getMiningSpeed() {
        return miningSpeed;
    }

    public void repair() {
        this.durability = 100; // Reset durability to 100
    }

    public abstract void use(Block block, Map worldMap, int x, int y);
}
