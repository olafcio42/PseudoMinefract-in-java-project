    package WorldMap;

    import Abstrakcje.Block;
    public class Map {
        private Block[][] blocks;

        public Map() {
            blocks = new Block[5][5];  // Tworzy mapę 10x10
        }

        public void placeBlock(Block block, int x, int y) {
            if (x >= 0 && x < blocks.length && y >= 0 && y < blocks[x].length) {
                blocks[x][y] = block;  // Umieszcza blok na mapie
            }
        }

        public Block getBlock(int x, int y) {
            if (x >= 0 && x < blocks.length && y >= 0 && y < blocks[x].length) {
                return blocks[x][y];  // Zwraca blok na podanych współrzędnych
            }
            return null;
        }

        public void removeBlock(int x, int y) {
            if (x >= 0 && x < blocks.length && y >= 0 && y < blocks[x].length) {
                blocks[x][y] = null;  // Usuwa blok z mapy
            }
        }
    }

