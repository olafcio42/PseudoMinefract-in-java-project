package Itemy;

import Abstrakcje.Block;
import Abstrakcje.Tool;
import WorldMap.Map;

public class Pickaxe extends Tool {

    public Pickaxe() {
        super(100, 15); // Przykładowa wytrzymałość i szybkość wydobycia dla Pickaxe
    }

    @Override
    public void use(Block block, Map worldMap, int x, int y) {
        if (!isBroken()) {
            block.reduceDurability(getMiningSpeed());
            decreaseDurability();
        }
    }
}
