package Itemy;

import Abstrakcje.Block;
import Abstrakcje.Tool;
import WorldMap.Map;

public class Axe extends Tool {

    public Axe() {
        super(100, 10); // Example durability and mining speed for Axe
    }

    @Override
    public void use(Block block, Map worldMap, int x, int y) {
        if (!isBroken()) {
            block.reduceDurability(getMiningSpeed());
            decreaseDurability();
        }
    }
}
