import java.util.Scanner;
import java.util.Random;

import Blocks.*;
import Entities.Player;
import Moby.Creeper;
import Itemy.Shovel;
import WorldMap.Map;
import Player.Inventory;
import Itemy.Axe;
import Itemy.Pickaxe;
import Abstrakcje.Block;
import Abstrakcje.Tool;
import Abstrakcje.Item;

public class Main {
    private static Inventory inventory;
    private static Player player;
    private static Creeper creeper;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map worldMap = new Map();
        initializeRandomBlocks(worldMap);

        Inventory playerInventory = new Inventory();

        Tool axe = new Axe();
        Tool pickaxe = new Pickaxe();
        Tool shovel = new Shovel();

        playerInventory.addItem(new Dirt(), 1);
        playerInventory.addItem(new Stone(), 2);
        playerInventory.addItem(new Wood(), 3);

        player = new Player("Steve", 100);
        creeper = new Creeper(50);

        boolean running = true;
        while (running) {
            if (player.isDead()) {
                System.out.println("Steve has died. Game over.");
                running = false;
                break;
            }

            System.out.println("Aktualny stan mapy:");
            displayMap(worldMap);
            System.out.println("Ekwipunek zawiera " + playerInventory.getItemCount() + " przedmiotów.");
            System.out.println(player.getStatus());
            System.out.println(creeper.getStatus());
            System.out.println("Wpisz polecenie (place, mine, repair, hit, status, exit, inventory):");
            String command = scanner.nextLine();
            if (command.equals("exit")) {
                running = false;
            } else if (command.equals("inventory")) {
                displayInventory(playerInventory);
            } else if (command.equals("repair")) {
                handleRepair(scanner, axe, pickaxe, shovel);
            } else if (command.equals("hit")) {
                handleHit(scanner);
            } else if (command.equals("status")) {
                System.out.println(player.getStatus());
                System.out.println(creeper.getStatus());
            } else {
                processCommand(command, scanner, worldMap, playerInventory, axe, pickaxe, shovel);
            }

            if (player.isDead()) {
                System.out.println("Steve has died. Game over.");
                running = false;
            }
        }
        scanner.close();
    }

    private static void initializeRandomBlocks(Map worldMap) {
        Random random = new Random();
        Block[] blockTypes = {new Dirt(), new Gravel(), new Iron(), new Stone(), new Wood()};
        for (int i = 0; i < 10; i++) {
            int x = random.nextInt(5);
            int y = random.nextInt(5);
            if (worldMap.getBlock(x, y) == null) {
                Block block = blockTypes[random.nextInt(blockTypes.length)];
                worldMap.placeBlock(block, x, y);
            } else {
                i--;
            }
        }
    }

    private static void displayMap(Map worldMap) {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                Block block = worldMap.getBlock(i, j);
                if (block instanceof Dirt) {
                    System.out.print("D ");
                } else if (block instanceof Stone) {
                    System.out.print("S ");
                } else if (block instanceof Gravel) {
                    System.out.print("G ");
                } else if (block instanceof Iron) {
                    System.out.print("I ");
                } else if (block instanceof Wood) {
                    System.out.print("W ");
                } else {
                    System.out.print(". ");
                }
            }
            System.out.println();
        }
    }

    private static void processCommand(String command, Scanner scanner, Map worldMap, Inventory inventory, Tool axe, Tool pickaxe, Tool shovel) {
        if (command.startsWith("place")) {
            handlePlace(scanner, worldMap, inventory);
        } else if (command.startsWith("mine")) {
            handleMine(scanner, worldMap, inventory, axe, pickaxe, shovel);
        } else {
            System.out.println("Nieznane polecenie.");
        }
    }

    private static void handlePlace(Scanner scanner, Map worldMap, Inventory inventory) {
        System.out.println("Wybierz blok: 1 dla Dirt, 2 dla Gravel, 3 dla Iron, 4 dla Stone, 5 dla Wood");
        int choice = Integer.parseInt(scanner.nextLine()) - 1;
        Block[] blocks = {new Dirt(), new Gravel(), new Iron(), new Stone(), new Wood()};
        if (choice < 0 || choice >= blocks.length) {
            System.out.println("Nieprawidłowy wybór.");
            return;
        }
        Block block = blocks[choice];
        if (!inventory.containsItem(block.getClass())) {
            System.out.println("Brak bloku w ekwipunku.");
            return;
        }
        System.out.println("Podaj współrzędne X i Y:");
        int x = scanner.nextInt();
        int y = scanner.nextInt();
        scanner.nextLine();
        if (worldMap.getBlock(x, y) == null) {
            worldMap.placeBlock(block, x, y);
            inventory.removeItem(block.getClass());
            System.out.println("Blok umieszczony.");
        } else {
            System.out.println("Miejsce już zajęte.");
        }
    }

    private static void handleMine(Scanner scanner, Map worldMap, Inventory inventory, Tool axe, Tool pickaxe, Tool shovel) {
        System.out.println("Podaj współrzędne X i Y:");
        int x = scanner.nextInt();
        int y = scanner.nextInt();
        scanner.nextLine();
        Block block = worldMap.getBlock(x, y);
        if (block != null) {
            System.out.println("Wybierz narzędzie: 1 dla Axe, 2 dla Pickaxe, 3 dla Shovel");
            int choice = scanner.nextInt();
            scanner.nextLine();
            Tool tool = null;
            if (choice == 1) {
                tool = axe;
            } else if (choice == 2) {
                tool = pickaxe;
            } else if (choice == 3) {
                tool = shovel;
            }
            if (tool != null) {
                if (!tool.isBroken()) {
                    tool.use(block, worldMap, x, y);
                    if (block.isDestroyed()) {
                        System.out.println("Podaj numer slotu (1-36):");
                        int slot = Integer.parseInt(scanner.nextLine());
                        if (inventory.canAddItem(block, slot)) {
                            inventory.addItem(block, slot);
                            worldMap.removeBlock(x, y);
                            System.out.println("Blok wykopany.");
                        } else {
                            System.out.println("Cannot add item to slot " + slot);
                        }
                    } else {
                        System.out.println("Blok uszkodzony ale nie zniszczony.");
                    }
                    System.out.println("Pozostała trwałość narzędzia: " + tool.getDurability());
                } else {
                    System.out.println("Narzędzie jest zepsute i nie może być używane.");
                }
            } else {
                System.out.println("Nieprawidłowy wybór narzędzia.");
            }
        } else {
            System.out.println("Brak bloku na podanych współrzędnych.");
        }
    }

    private static void handleRepair(Scanner scanner, Tool axe, Tool pickaxe, Tool shovel) {
        System.out.println("Wybierz narzędzie do naprawy: 1 dla Axe, 2 dla Pickaxe, 3 dla Shovel");
        int choice = Integer.parseInt(scanner.nextLine());
        Tool tool = null;
        if (choice == 1) {
            tool = axe;
        } else if (choice == 2) {
            tool = pickaxe;
        } else if (choice == 3) {
            tool = shovel;
        }
        if (tool != null) {
            tool.repair();
            System.out.println("Narzędzie naprawione.");
        } else {
            System.out.println("Nieprawidłowy wybór narzędzia.");
        }
    }

    private static void handleHit(Scanner scanner) {
        System.out.println("Wybierz cel: 1 dla gracza, 2 dla creepera");
        int target = Integer.parseInt(scanner.nextLine());
        System.out.println("Podaj ilość obrażeń:");
        int damage = Integer.parseInt(scanner.nextLine());
        if (target == 1) {
            player.hit(damage);
            System.out.println("Gracz otrzymał " + damage + " obrażeń.");
        } else if (target == 2) {
            creeper.hit(damage);
            System.out.println("Creeper otrzymał " + damage + " obrażeń.");
        } else {
            System.out.println("Nieprawidłowy cel.");
        }
    }

    private static void displayInventory(Inventory inventory) {
        System.out.println("Zawartość ekwipunku:");
        inventory.displayItems();
    }
}
